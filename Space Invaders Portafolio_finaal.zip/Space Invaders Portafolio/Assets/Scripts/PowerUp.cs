using UnityEngine;

public class PowerUp : MonoBehaviour
{
    [SerializeField] private float fallSpeed = 3.0f;
    [SerializeField] private float yScreenLimit = -6.0f;

    [Header("Configuraci�n del Poder desde Unity")]
    [Tooltip("Por cu�nto se multiplicar� la velocidad base (ej: 1.5 = 50% m�s r�pido, 2.0 = doble de velocidad)")]
    [SerializeField] private float multiplicadorVelocidad = 1.7f;

    [Tooltip("Duraci�n del efecto en segundos")]
    [SerializeField] private float duracionEfecto = 5.0f;

    private void Update()
    {
        
        transform.Translate(Vector3.down * fallSpeed * Time.deltaTime);

        if (transform.position.y < yScreenLimit)
        {
            Destroy(gameObject);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        
        if (other.CompareTag("Player"))
        {
            PlayerController player = other.GetComponent<PlayerController>();
            
            if (player != null)
            {
                UIManager.Instance.SumarPuntos(500);
                
                player.ActivarVelocidadExtra(multiplicadorVelocidad, duracionEfecto);
            }

            Destroy(gameObject); 
        }
    }
}