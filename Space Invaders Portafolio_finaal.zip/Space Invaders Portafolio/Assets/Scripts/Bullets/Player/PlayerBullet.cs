using UnityEngine;

public class PlayerBullet : MonoBehaviour
{
    [SerializeField] private float speed = 10f;
    [SerializeField] private float yLimit = 6f;

    [Header("Efecto de Muerte")]
    [SerializeField] private GameObject deathParticlesPrefab;

    private void Update()
    {
        transform.Translate(Vector3.up * speed * Time.deltaTime);

        if (transform.position.y > yLimit)
        {
            gameObject.SetActive(false);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Enemigo"))
        {
            EnemyShooter enemyShooter = other.GetComponent<EnemyShooter>();

            if (enemyShooter != null)
            {
                Gradient enemyGradient = enemyShooter.GetDeathGradient();

                if (deathParticlesPrefab != null)
                {
                    GameObject effect = Instantiate(deathParticlesPrefab, other.transform.position, Quaternion.identity);
                    EnemyDeathParticles deathScript = effect.GetComponent<EnemyDeathParticles>();

                    if (deathScript != null)
                    {
                        deathScript.InicializarMuerte(enemyGradient);
                    }
                }
            }

            EnemyHealth health = other.GetComponent<EnemyHealth>();
            if (health != null)
            {
                health.RecibirImpacto();
            }

           
            gameObject.SetActive(false);
        }
    }
}