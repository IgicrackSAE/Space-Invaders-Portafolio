using UnityEngine;

public class EnemyDeathParticles : MonoBehaviour
{
    private ParticleSystem pts;

    private void Awake()
    {
        pts = GetComponent<ParticleSystem>();
    }

    public void InicializarMuerte(Gradient gradienteEnemigo)
    {
        if (pts == null) pts = GetComponent<ParticleSystem>();

        var mainModule = pts.main;
        mainModule.startColor = new ParticleSystem.MinMaxGradient(gradienteEnemigo);
        pts.Play();
        Destroy(gameObject, mainModule.duration + mainModule.startLifetime.constantMax);
    }
}