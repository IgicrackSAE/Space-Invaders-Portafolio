using UnityEngine;

public class EnemyHealth : MonoBehaviour
{
    public void RecibirImpacto()
    {  
        if (UIManager.Instance != null)
        {
            UIManager.Instance.SumarPuntos(100);
        }

        gameObject.SetActive(false);
    }
}