using UnityEngine;

public class EnemyGridManager : MonoBehaviour
{
    [System.Serializable]
    public struct RowConfig
    {
        public GameObject enemyPrefab;
        public int count;
    }

    [SerializeField] private EnemyObjectPool objectPool;
    [SerializeField] private EnemyBulletPool enemyBulletPool;
    [SerializeField] private RowConfig[] rowsConfiguration;
    [SerializeField] private int columns = 11;
    [SerializeField] private float hSpacing = 1.2f;
    [SerializeField] private float vSpacing = 1.2f;

    private EnemyMovement movementScript;

    private void Start()
    {
        movementScript = GetComponent<EnemyMovement>();

        if (objectPool == null)
        {
            Debug.LogError($"Falta asignar el 'EnemyObjectPool' en {gameObject.name}.", gameObject);
            return;
        }

        if (enemyBulletPool == null)
        {
            Debug.LogError($"Falta asignar el 'EnemyBulletPool' en {gameObject.name}.", gameObject);
            return;
        }

        GenerarOleada();
    }

    public void GenerarOleada()
    {
        if (objectPool == null) return;

        int totalRows = 0;
        foreach (var config in rowsConfiguration) totalRows += config.count;

        float totalWidth = (columns - 1) * hSpacing;
        float totalHeight = (totalRows - 1) * vSpacing;
        Vector3 centerOffset = new Vector3(totalWidth / 2f, -totalHeight / 2f, 0);

        int currentRowIndex = 0;

        foreach (var config in rowsConfiguration)
        {
            if (config.enemyPrefab == null) continue;

            for (int r = 0; r < config.count; r++)
            {
                for (int col = 0; col < columns; col++)
                {
                    Vector3 localPosition = new Vector3(col * hSpacing, -currentRowIndex * vSpacing, 0) - centerOffset;
                    Vector3 worldPosition = transform.TransformPoint(localPosition);

                    GameObject enemy = objectPool.GetEnemyFromPool(config.enemyPrefab);

                    if (enemy != null)
                    {
                        enemy.transform.position = worldPosition;
                        enemy.transform.rotation = Quaternion.identity;
                        enemy.transform.SetParent(transform);

                        EnemyShooter shooter = enemy.GetComponent<EnemyShooter>();
                        if (shooter != null)
                        {
                            shooter.SetBulletPool(enemyBulletPool);
                        }

                        enemy.SetActive(true);
                    }
                }
                currentRowIndex++;
            }
        }

        if (movementScript != null)
        {
            movementScript.ResetInitialCount();
        }
    }
}