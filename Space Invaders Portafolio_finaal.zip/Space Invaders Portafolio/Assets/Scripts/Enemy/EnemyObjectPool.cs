using System.Collections.Generic;
using UnityEngine;

public class EnemyObjectPool : MonoBehaviour
{
    private Dictionary<string, List<GameObject>> pools = new Dictionary<string, List<GameObject>>();

    public GameObject GetEnemyFromPool(GameObject prefab)
    {
        if (prefab == null) return null;

        string key = prefab.name;

        if (!pools.ContainsKey(key))
        {
            pools.Add(key, new List<GameObject>());
        }

        for (int i = 0; i < pools[key].Count; i++)
        {
            if (!pools[key][i].activeInHierarchy)
            {
                return pools[key][i];
            }
        }

        GameObject newEnemy = Instantiate(prefab, transform);
        newEnemy.SetActive(false);
        pools[key].Add(newEnemy);
        return newEnemy;
    }
}