using UnityEngine;

public class EnemyMovement : MonoBehaviour
{
    [SerializeField] private float baseSpeed = 1.5f;
    [SerializeField] private float maxSpeed = 8.0f;
    [SerializeField] private AnimationCurve speedCurve = AnimationCurve.Linear(0f, 0f, 1f, 1f);
    [SerializeField] private float downDistance = 0.5f;

    private Vector3 direction = Vector3.right;
    private bool isStepDownPending = false;
    private BoxCollider2D parentCollider;
    private int initialEnemyCount = 0;

    private void Start()
    {
        parentCollider = gameObject.GetComponent<BoxCollider2D>();
        if (parentCollider == null) parentCollider = gameObject.AddComponent<BoxCollider2D>();
        parentCollider.isTrigger = true;

        Rigidbody2D rb = gameObject.GetComponent<Rigidbody2D>();
        if (rb == null) rb = gameObject.AddComponent<Rigidbody2D>();
        rb.bodyType = RigidbodyType2D.Kinematic;
        rb.useFullKinematicContacts = true;
    }

    public void ResetInitialCount()
    {
        initialEnemyCount = GetActiveEnemyCount();
    }

    public void SetNewWaveSpeed(float multiplier)
    {
        baseSpeed *= multiplier;
        maxSpeed *= multiplier;
    }

    private void Update()
    {
        int currentActiveEnemies = GetActiveEnemyCount();
        if (currentActiveEnemies == 0 || initialEnemyCount == 0) return;

        float totalEliminated = initialEnemyCount - currentActiveEnemies;
        float progressFactor = totalEliminated / initialEnemyCount;
        float curveEvaluation = speedCurve.Evaluate(progressFactor);
        float currentSpeed = Mathf.Lerp(baseSpeed, maxSpeed, curveEvaluation);

        transform.Translate(direction * currentSpeed * Time.deltaTime);
        UpdateColliderBounds();
    }

    private int GetActiveEnemyCount()
    {
        int activeCount = 0;
        foreach (Transform child in transform)
        {
            if (child.gameObject.activeSelf) activeCount++;
        }
        return activeCount;
    }

    private void UpdateColliderBounds()
    {
        bool firstTargetFound = false;
        Bounds bounds = new Bounds();

        foreach (Transform child in transform)
        {
            if (!child.gameObject.activeSelf) continue;

            Collider2D childCollider = child.GetComponent<Collider2D>();
            if (childCollider != null)
            {
                if (!firstTargetFound)
                {
                    bounds = new Bounds(child.position, Vector3.zero);
                    bounds.Encapsulate(childCollider.bounds);
                    firstTargetFound = true;
                }
                else
                {
                    bounds.Encapsulate(childCollider.bounds);
                }
            }
        }

        if (firstTargetFound)
        {
            parentCollider.enabled = true;
            parentCollider.offset = transform.InverseTransformPoint(bounds.center);
            parentCollider.size = transform.InverseTransformDirection(bounds.size);
        }
        else
        {
            parentCollider.enabled = false;
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Borde") && !isStepDownPending)
        {
            isStepDownPending = true;
            direction = -direction;
            transform.position += Vector3.down * downDistance;

            Invoke(nameof(ResetStepDown), 0.2f);
        }
    }

    private void ResetStepDown()
    {
        isStepDownPending = false;
    }
}