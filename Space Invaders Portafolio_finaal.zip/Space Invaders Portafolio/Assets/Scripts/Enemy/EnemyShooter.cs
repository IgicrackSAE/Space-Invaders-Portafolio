using UnityEngine;

public class EnemyShooter : MonoBehaviour
{
    [Header("Tiempos Base de Disparo (Segundos)")]
    [SerializeField] private float minFireInterval = 2.0f;
    [SerializeField] private float maxFireInterval = 10.0f;

    [Header("Control de Cadencia desde Unity")]
    [SerializeField] private float globalFireRateMultiplier = 1.0f;

    [Header("Configuraci�n F�sica y Visual")]
    [SerializeField] private float raycastDistance = 5.0f;
    [SerializeField] private LayerMask enemyLayer;

    [Header("Efecto de Muerte")]
    [Tooltip("Configura los dos colores usando los nodos de abajo de la barra de gradiente")]
    [SerializeField] private Gradient deathParticleGradient;

    private EnemyBulletPool bulletPool;
    private float nextFireTime;

    private void OnEnable()
    {
        CalculateNextFireTime();
    }

    private void Start()
    {
        CalculateNextFireTime();
    }

    public void SetBulletPool(EnemyBulletPool pool)
    {
        bulletPool = pool;
    }

    public Gradient GetDeathGradient()
    {
        return deathParticleGradient;
    }

    private void Update()
    {
        if (Time.time >= nextFireTime)
        {
            if (IsFrontRow())
            {
                Shoot();
            }
            CalculateNextFireTime();
        }
    }

    private bool IsFrontRow()
    {
        Vector2 origin = transform.position;
        RaycastHit2D hit = Physics2D.Raycast(origin + Vector2.down * 0.6f, Vector2.down, raycastDistance, enemyLayer);

        if (hit.collider != null)
        {
            return false;
        }

        return true;
    }

    private void Shoot()
    {
        if (bulletPool == null) return;

        GameObject bullet = bulletPool.GetBullet();
        if (bullet != null)
        {
            bullet.transform.position = transform.position + Vector3.down * 0.5f;
            bullet.transform.rotation = Quaternion.identity;
            bullet.SetActive(true);
        }
    }

    private void CalculateNextFireTime()
    {
        float multiplier = Mathf.Max(globalFireRateMultiplier, 0.01f);
        float randomDelay = Random.Range(minFireInterval, maxFireInterval) / multiplier;
        nextFireTime = Time.time + randomDelay;
    }
}