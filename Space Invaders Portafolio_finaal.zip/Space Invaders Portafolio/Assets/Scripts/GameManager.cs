using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    [Header("Configuraci�n de Enemigos")]
    [SerializeField] private EnemyGridManager gridManager;
    [SerializeField] private EnemyMovement movementScript;

    [Header("Referencias Adicionales")]
    [SerializeField] private MonoBehaviour cameraShakeScript; 

    [Header("Configuraci�n de Oleadas")]
    [SerializeField] private float timeBetweenWaves = 2.0f;
    [SerializeField] private float speedMultiplierPerWave = 1.15f;

    private int currentWave = 1;
    private bool isTransitioningWave = false;
    private bool isGameOver = false;
    private Vector3 initialGridPosition;

    private void Awake()
    {
        if (Instance == null) Instance = this;
        else { Destroy(gameObject); return; }
    }

    private void Start()
    {
        Time.timeScale = 1f;
        initialGridPosition = movementScript != null ? movementScript.transform.position : Vector3.zero;
    }

    private void Update()
    {
        if (isTransitioningWave || isGameOver) return;
        if (AreAllEnemiesDefeated()) StartCoroutine(NextWaveRoutine());
    }

    private IEnumerator NextWaveRoutine()
    {
        isTransitioningWave = true;
        currentWave++;
        if (UIManager.Instance != null) UIManager.Instance.SumarPuntos(10000);
        yield return new WaitForSeconds(timeBetweenWaves);

        Bunker[] todosLosBunkeres = Object.FindObjectsByType<Bunker>(FindObjectsInactive.Include);
        foreach (Bunker bunker in todosLosBunkeres) bunker.Regenerar();

        if (movementScript != null)
        {
            movementScript.SetNewWaveSpeed(speedMultiplierPerWave);
            movementScript.transform.position = initialGridPosition;
        }
        if (gridManager != null) gridManager.GenerarOleada();
        isTransitioningWave = false;
    }

    private bool AreAllEnemiesDefeated()
    {
        if (gridManager == null) return false;
        foreach (Transform child in gridManager.transform) if (child.gameObject.activeSelf) return false;
        return true;
    }

    public void PerderJuego()
    {
        if (isGameOver) return;
        isGameOver = true;

        
        if (cameraShakeScript != null)
        {
            cameraShakeScript.StopAllCoroutines();
            cameraShakeScript.transform.localPosition = Vector3.zero;
        }

        
        Time.timeScale = 0f;
        StartCoroutine(GameOverRoutine());
    }

        private IEnumerator GameOverRoutine()
    {
        Debug.Log("Iniciando rutina de Game Over...");

        if (UIManager.Instance != null)
        {
            UIManager.Instance.ActivarGameOver();
            int puntosFinales = UIManager.Instance.GetScore();
            RegistrarPuntajeEnRanking(puntosFinales);
            PlayerPrefs.Save();
            Debug.Log("UI activada y puntos guardados.");
        }

        yield return new WaitForSecondsRealtime(3.0f);
        Debug.Log("Espera de 3 segundos terminada. Llamando a la transici�n...");

        if (SceneTransition.Instance != null)
        {
            SceneTransition.Instance.FadeToScene("Menu_Principal");
        }
        else
        {
            Debug.LogError("�ERROR! No se encuentra SceneTransition.Instance. �El objeto fue destruido?");
        }
    }

    private void RegistrarPuntajeEnRanking(int nuevoPuntaje)
    {
        string nombre = PlayerPrefs.GetString("JugadorActual", "Anonimo");
        for (int i = 1; i <= 10; i++)
        {
            int recordActual = PlayerPrefs.GetInt("Score" + i, 0);
            if (nuevoPuntaje > recordActual)
            {
                PlayerPrefs.SetString("Name" + i, nombre);
                PlayerPrefs.SetInt("Score" + i, nuevoPuntaje);
                PlayerPrefs.Save();
                break;
            }
        }
    }
}