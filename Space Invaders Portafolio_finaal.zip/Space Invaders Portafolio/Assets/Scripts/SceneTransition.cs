using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

public class SceneTransition : MonoBehaviour
{
    [SerializeField] private CanvasGroup fadeGroup;
    public static SceneTransition Instance;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

        
    private void OnEnable()
    {
        if (fadeGroup != null) fadeGroup.alpha = 0f;
    }

    public void FadeToScene(string sceneName)
    {
        StartCoroutine(FadeRoutine(sceneName));
    }

    private IEnumerator FadeRoutine(string sceneName)
    {
        fadeGroup.blocksRaycasts = true;
        float speed = 2f;

        // Fade Out (negro)
        while (fadeGroup.alpha < 1)
        {
            fadeGroup.alpha += Time.unscaledDeltaTime * speed;
            yield return null;
        }

        SceneManager.LoadScene(sceneName);

        yield return new WaitForSecondsRealtime(0.5f);

        // Fade In (transparente)
        while (fadeGroup.alpha > 0)
        {
            fadeGroup.alpha -= Time.unscaledDeltaTime * speed;
            yield return null;
        }

        fadeGroup.blocksRaycasts = false;
    }
}