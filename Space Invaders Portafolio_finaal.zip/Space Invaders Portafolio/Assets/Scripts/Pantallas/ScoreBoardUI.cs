using UnityEngine;
using TMPro;

public class ScoreBoardUI : MonoBehaviour
{
    public GameObject panelRanking;

    public TextMeshProUGUI[] textosRanking = new TextMeshProUGUI[10];

    public void AbrirRanking()
    {
        panelRanking.SetActive(true);

        for (int i = 0; i < 10; i++)
        {
            int rank = i + 1;
            string nombre = PlayerPrefs.GetString("Name" + rank, "---");
            int score = PlayerPrefs.GetInt("Score" + rank, 0);

            if (textosRanking[i] != null)
            {
                textosRanking[i].text = $"{rank}. {nombre} : {score.ToString("D5")}";
            }
        }
    }
    public void CargarDatosDePrueba()
    {
        PlayerPrefs.SetString("Name1", "JUGADOR_1");
        PlayerPrefs.SetInt("Score1", 99999);

        PlayerPrefs.SetString("Name2", "JUGADOR_2");
        PlayerPrefs.SetInt("Score2", 50000);

        PlayerPrefs.SetString("Name3", "JUGADOR_3");
        PlayerPrefs.SetInt("Score3", 10000);

        PlayerPrefs.Save();

        Debug.Log("Datos de prueba guardados. Abre el ranking ahora.");
    }

    public void ReiniciarPuntajes()
    {
        for (int i = 1; i <= 10; i++)
        {
            PlayerPrefs.DeleteKey("Name" + i);
            PlayerPrefs.DeleteKey("Score" + i);
        }

        PlayerPrefs.Save();

        AbrirRanking();

        Debug.Log("Ranking reseteado exitosamente.");
    }
    public void CerrarRanking() => panelRanking.SetActive(false);
}