using TMPro;
using UnityEngine;
using System.Collections;

public class MainMenu : MonoBehaviour
{
    [SerializeField] private string nombreEscenaJuego = "Juego";
    [SerializeField] private GameObject panelNombre;
    [SerializeField] private CanvasGroup panelNombreGroup;
    [SerializeField] private TMP_InputField nombreInput;

    public void AbrirPanelNombre() => StartCoroutine(FadePanelRoutine(true));

    private IEnumerator FadePanelRoutine(bool mostrar)
    {
        float speed = 5f;
        if (mostrar)
        {
            panelNombre.SetActive(true);
            panelNombreGroup.interactable = true;
            panelNombreGroup.blocksRaycasts = true;
            while (panelNombreGroup.alpha < 1) { panelNombreGroup.alpha += Time.unscaledDeltaTime * speed; yield return null; }
        }
        else
        {
            panelNombreGroup.blocksRaycasts = false;
            panelNombreGroup.interactable = false;
            while (panelNombreGroup.alpha > 0) { panelNombreGroup.alpha -= Time.unscaledDeltaTime * speed; yield return null; }
            panelNombre.SetActive(false);
        }
    }

    public void IniciarJuego()
    {
        if (nombreInput.text.Length >= 3)
        {
            PlayerPrefs.SetString("JugadorActual", nombreInput.text);
            PlayerPrefs.Save();
            SceneTransition.Instance.FadeToScene(nombreEscenaJuego);
        }
    }
    
    public void SalirJuego()
    {
        Debug.Log("Cerrando juego...");

        #if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
        #else
            Application.Quit();
        #endif
    }
}