using UnityEngine;

public class SupplyShipSpawner : MonoBehaviour
{
    [Header("Configuraci�n del Spawn")]
    [SerializeField] private GameObject supplyShipPrefab; 
    [SerializeField] private float ySpawnHeight = 5.0f;   
    [SerializeField] private float xSpawnOffset = 8.5f;  

    [Header("Tiempos de Aparici�n (Segundos)")]
    [SerializeField] private float minSpawnDelay = 15.0f;  
    [SerializeField] private float maxSpawnDelay = 30.0f; 

    private float nextSpawnTime;

    private void Start()
    {
        
        CalcularSiguienteSpawn();
    }

    private void Update()
    {
        if (Time.time >= nextSpawnTime)
        {
            SpawnShip();
            CalcularSiguienteSpawn();
        }
    }

    private void SpawnShip()
    {
        if (supplyShipPrefab == null) return;

        int ladoAleatorio = Random.Range(0, 2);
        int direccion = (ladoAleatorio == 0) ? 1 : -1;

        float spawnX = (direccion == 1) ? -xSpawnOffset : xSpawnOffset;
        Vector3 spawnPosition = new Vector3(spawnX, ySpawnHeight, 0f);

        GameObject newShip = Instantiate(supplyShipPrefab, spawnPosition, Quaternion.identity);

        SupplyShip shipScript = newShip.GetComponent<SupplyShip>();
        if (shipScript != null)
        {
            shipScript.InicializarNave(direccion);
        }
    }

    private void CalcularSiguienteSpawn()
    {
        nextSpawnTime = Time.time + Random.Range(minSpawnDelay, maxSpawnDelay);
    }
}