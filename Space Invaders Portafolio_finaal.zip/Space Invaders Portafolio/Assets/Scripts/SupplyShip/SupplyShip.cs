using UnityEngine;

public class SupplyShip : MonoBehaviour
{
    [Header("Movimiento")]
    [SerializeField] private float speed = 4.0f;
    [SerializeField] private float xLimit = 9.0f; // Punto donde se destruye al salir de la pantalla

    [Header("Suministros")]
    [SerializeField] private GameObject powerUpPrefab; // El item que va a soltar

    private int direccion = 1; // 1 = Derecha, -1 = Izquierda
    private bool yaSoltoPoder = false;
    private float puntoDeSoltadoX;

    public void InicializarNave(int dir)
    {
        direccion = dir;
        yaSoltoPoder = false;

        // Calcula un punto aleatorio en la pantalla (entre -5 y 5 en el eje X) para soltar el poder en medio del viaje
        puntoDeSoltadoX = Random.Range(-5.0f, 5.0f);
    }

    private void Update()
    {
        // Se mueve horizontalmente de forma recta
        transform.Translate(Vector3.right * direccion * speed * Time.deltaTime);

        // Verifica si ya cruz� el punto aleatorio para soltar el poder
        if (!yaSoltoPoder)
        {
            // Si va a la derecha y pas� el punto, o si va a la izquierda y cay� por debajo del punto
            if ((direccion == 1 && transform.position.x >= puntoDeSoltadoX) ||
                (direccion == -1 && transform.position.x <= puntoDeSoltadoX))
            {
                SoltarPowerUp();
            }
        }

        // Se auto-destruye si sale por completo del mapa
        if ((direccion == 1 && transform.position.x > xLimit) ||
            (direccion == -1 && transform.position.x < -xLimit))
        {
            Destroy(gameObject);
        }
    }

    private void SoltarPowerUp()
    {
        yaSoltoPoder = true;

        if (powerUpPrefab != null)
        {
            // Instancia el item justo debajo de la posici�n actual de la nave esp�a
            Instantiate(powerUpPrefab, transform.position + Vector3.down * 0.5f, Quaternion.identity);
        }
    }
}   