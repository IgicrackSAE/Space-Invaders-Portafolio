using UnityEngine;

[RequireComponent(typeof(BoxCollider2D))]
public class LoseZone : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Enemigo"))
        {
            Debug.Log($"[LoseZone] �Invasi�n detectada! El enemigo '{other.gameObject.name}' cruz� la l�nea de defensa.");

            if (GameManager.Instance != null)
            {
                GameManager.Instance.PerderJuego();
            }
            else
            {
                Debug.LogError("[LoseZone] �Error cr�tico! No se encontr� ninguna instancia activa del GameManager en la escena.");
            }
        }
    }
}