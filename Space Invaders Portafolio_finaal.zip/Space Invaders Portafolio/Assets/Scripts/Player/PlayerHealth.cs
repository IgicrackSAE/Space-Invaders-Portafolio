using System.Collections; 
using UnityEngine;

public class PlayerHealth : MonoBehaviour
{
    [Header("Configuraci�n de Vida")]
    [SerializeField] private int maxHealth = 3;
    [SerializeField] private float tiempoInvulnerabilidad = 2.0f;

    [Header("Efecto de Impacto (Camera Shake)")]
    [SerializeField] private float shakeDuration = 0.2f;
    [SerializeField] private float shakeMagnitude = 0.3f;

    [Header("Efecto de Impacto (Part�culas)")]
    [SerializeField] private ParticleSystem hitParticles;

    private int currentHealth;
    private CameraShake cameraShakeScript;
    private PlayerController playerController;
    private SpriteRenderer spriteRenderer;

    private void Start()
    {
        currentHealth = maxHealth;

        if (UIManager.Instance != null)
        {
            UIManager.Instance.InicializarVidas(maxHealth);
        }
        else
        {
            Debug.LogWarning("[PlayerHealth] �No se encontr� el UIManager para dibujar las vidas al iniciar!");
        }

        if (Camera.main != null)
        {
            cameraShakeScript = Camera.main.GetComponent<CameraShake>();
        }

        playerController = GetComponent<PlayerController>();
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    public void TakeDamage(int damageAmount)
    {
        if (playerController != null && playerController.EsInvulnerable())
        {
            Debug.Log("�Ataque bloqueado! El jugador es invulnerable actualmente.");
            return;
        }

        currentHealth -= damageAmount;
        Debug.Log($"�El jugador recibi� da�o! Vida actual: {currentHealth}");

        if (UIManager.Instance != null)
        {
            for (int i = 0; i < damageAmount; i++)
            {
                UIManager.Instance.ReducirVida();
            }
        }
  
        if (cameraShakeScript != null)
        {
            cameraShakeScript.Shake(shakeDuration, shakeMagnitude);
        }

        if (hitParticles != null)
        {
            hitParticles.Play();
        }

        if (playerController != null && currentHealth > 0)
        {
            playerController.ActivarInvulnerabilidadTemporal(tiempoInvulnerabilidad);
            StartCoroutine(RoutineParpadeo(tiempoInvulnerabilidad));
        }

        if (currentHealth <= 0)
        {
            Die();
        }
    }
    private IEnumerator RoutineParpadeo(float duracionTotal)
    {
        if (spriteRenderer == null) yield break;

        float tiempoTranscurrido = 0f;
        float intervaloParpadeo = 0.1f;

        while (tiempoTranscurrido < duracionTotal)
        {
            spriteRenderer.enabled = !spriteRenderer.enabled;

            yield return new WaitForSeconds(intervaloParpadeo);

            tiempoTranscurrido += intervaloParpadeo;
        }

        spriteRenderer.enabled = true;
    }

    private void Die()
    {
        Debug.Log("�El jugador ha sido destruido!");

        if (GameManager.Instance != null)
        {
            GameManager.Instance.PerderJuego();
        }

        gameObject.SetActive(false);
    }
}