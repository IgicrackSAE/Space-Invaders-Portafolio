using System.Collections;
using UnityEngine;

public interface IPlayerState
{
    float ObtenerVelocidad(float velocidadBase);
    bool PuedeRecibirDano();
}

[RequireComponent(typeof(Rigidbody2D))]
public class PlayerController : MonoBehaviour
{
    [SerializeField] private float baseSpeed = 6.0f;
    [SerializeField] private float xScreenLimit = 7.5f;

    [Header("Efecto de Inclinaci�n Visual")]
    [SerializeField] private float maxTiltAngle = 15f;
    [SerializeField] private float tiltSpeed = 10f;

    private float horizontalInput;
    private Rigidbody2D rb;
    private IPlayerState estadoActual;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        rb.bodyType = RigidbodyType2D.Kinematic;
        rb.gravityScale = 0f;

        CambiarEstado(new EstadoNormal());
    }

    private void Update()
    {
        horizontalInput = 0f;

        if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow))
        {
            horizontalInput = -1f;
        }
        else if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow))
        {
            horizontalInput = 1f;
        }

        AjustarInclinacion();
    }

    private void FixedUpdate()
    {
        if (Mathf.Abs(horizontalInput) > 0.01f)
        {
            float velocidadCalculada = estadoActual.ObtenerVelocidad(baseSpeed);

            float moveX = horizontalInput * velocidadCalculada * Time.fixedDeltaTime;
            Vector2 nextPosition = rb.position + new Vector2(moveX, 0f);

            nextPosition.x = Mathf.Clamp(nextPosition.x, -xScreenLimit, xScreenLimit);

            rb.MovePosition(nextPosition);
        }
    }

    private void AjustarInclinacion()
    {
        float targetZRotation = -horizontalInput * maxTiltAngle;
        Quaternion targetRotation = Quaternion.Euler(0f, 0f, targetZRotation);
        transform.localRotation = Quaternion.Lerp(transform.localRotation, targetRotation, Time.deltaTime * tiltSpeed);
    }

    public void CambiarEstado(IPlayerState nuevoEstado)
    {
        estadoActual = nuevoEstado;
        Debug.Log($"El jugador cambi� al estado: {nuevoEstado.GetType().Name}");
    }

    public bool EsInvulnerable()
    {
        return !estadoActual.PuedeRecibirDano();
    }

    public void ActivarVelocidadExtra(float factorMultiplicador, float duracion)
    {
        StopAllCoroutines();
        StartCoroutine(RoutineContarPoder(factorMultiplicador, duracion));
    }

    private IEnumerator RoutineContarPoder(float multiplicador, float duracion)
    {
        CambiarEstado(new EstadoVelocidad(multiplicador));
        yield return new WaitForSeconds(duracion);
        CambiarEstado(new EstadoNormal());
    }

    public void ActivarInvulnerabilidadTemporal(float duracion)
    {
        StopAllCoroutines();
        StartCoroutine(RoutineInvulnerabilidad(duracion));
    }

    private IEnumerator RoutineInvulnerabilidad(float duracion)
    {
        CambiarEstado(new EstadoInvulnerable());
        yield return new WaitForSeconds(duracion);
        CambiarEstado(new EstadoNormal());
    }
}

public class EstadoNormal : IPlayerState
{
    public float ObtenerVelocidad(float velocidadBase) => velocidadBase;
    public bool PuedeRecibirDano() => true;
}

public class EstadoVelocidad : IPlayerState
{
    private float multiplicador;
    public EstadoVelocidad(float nuevoMultiplicador) => this.multiplicador = nuevoMultiplicador;

    public float ObtenerVelocidad(float velocidadBase) => velocidadBase * multiplicador;
    public bool PuedeRecibirDano() => true;
}

public class EstadoInvulnerable : IPlayerState
{
    public float ObtenerVelocidad(float velocidadBase) => velocidadBase;
    public bool PuedeRecibirDano() => false;
}