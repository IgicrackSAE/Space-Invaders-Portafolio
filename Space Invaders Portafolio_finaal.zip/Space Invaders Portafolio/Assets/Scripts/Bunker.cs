using UnityEngine;

[RequireComponent(typeof(SpriteRenderer))]
[RequireComponent(typeof(BoxCollider2D))]
public class Bunker : MonoBehaviour
{
    [Header("Sprites de Desgaste")]
    [SerializeField] private Sprite[] spritesDesgaste;

    private int vidaActual;
    private SpriteRenderer spriteRenderer;

    private void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    private void Start()
    {
        Regenerar();
    }

    public void Regenerar()
    {
        if (spritesDesgaste != null && spritesDesgaste.Length > 0)
        {
            vidaActual = spritesDesgaste.Length;
            spriteRenderer.sprite = spritesDesgaste[0];
        }
        else
        {
            vidaActual = 1;
        }

        gameObject.SetActive(true);
    }

    public void RecibirDano()
    {
        vidaActual--;

        if (vidaActual <= 0)
        {
            OcultarBunker();
        }
        else
        {
            int indiceSprite = spritesDesgaste.Length - vidaActual;

            if (indiceSprite < spritesDesgaste.Length)
            {
                spriteRenderer.sprite = spritesDesgaste[indiceSprite];
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("BalaJugador") || other.CompareTag("BalaEnemiga"))
        {
            RecibirDano();
            other.gameObject.SetActive(false);
        }
    }

    private void OcultarBunker()
    {
        Debug.Log($"B�nker {gameObject.name} se ha roto. Ocultando para la siguiente ronda.");
        gameObject.SetActive(false);
    }
}