using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class UIManager : MonoBehaviour
{
    public static UIManager Instance { get; private set; }

    [Header("Componentes de UI")]
    [SerializeField] private TextMeshProUGUI scoreText;
    [SerializeField] private Transform vidasContainer;

    [Header("Prefabs de Vidas")]
    [SerializeField] private GameObject vidaPrefab;

    private List<GameObject> iconosVidasActivos = new List<GameObject>();

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void ActualizarScore(int nuevoPuntaje)
    {
        if (scoreText != null)
        {
            scoreText.text = $"SCORE: {nuevoPuntaje.ToString("D5")}";
        }
    }

    public void InicializarVidas(int vidasIniciales)
    {
        foreach (GameObject icono in iconosVidasActivos)
        {
            if (icono != null) Destroy(icono);
        }
        iconosVidasActivos.Clear();

        for (int i = 0; i < vidasIniciales; i++)
        {
            GameObject nuevoIcono = Instantiate(vidaPrefab, vidasContainer);
            iconosVidasActivos.Add(nuevoIcono);
        }
    }

    public void ReducirVida()
    {
        if (iconosVidasActivos.Count > 0)
        {
            int ultimoIndice = iconosVidasActivos.Count - 1;
            Destroy(iconosVidasActivos[ultimoIndice]);
            iconosVidasActivos.RemoveAt(ultimoIndice);
        }
    }

    private int scoreActual = 0;

    public void SumarPuntos(int puntos)
    {
        scoreActual += puntos;
        ActualizarScore(scoreActual);
    }

    public int GetScore()
    {
        return scoreActual;
    }
}