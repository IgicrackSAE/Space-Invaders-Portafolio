using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MainMenu : MonoBehaviour
{
    [Header("Configuraci�n de Escenas")]
    [SerializeField] private string nombreEscenaJuego = "Juego";

    [Header("Referencias UI")]
    [SerializeField] private GameObject panelNombre;
    [SerializeField] private GameObject panelRanking;
    [SerializeField] private TMP_InputField nombreInput;

    public void AbrirPanelNombre()
    {
        panelNombre.SetActive(true);
    }

    public void IniciarJuego()
    {
        if (nombreInput.text.Length >= 3)
        {
            PlayerPrefs.SetString("JugadorActual", nombreInput.text);
            SceneManager.LoadScene(nombreEscenaJuego);
        }
        else
        {
            Debug.LogWarning("El nombre debe tener al menos 3 caracteres.");
        }
    }

    public void Salir()
    {
        Debug.Log("Saliendo del juego...");
        Application.Quit();
    }

    public void AbrirRanking()
    {
        panelRanking.SetActive(true);
    }

    public void CerrarRanking()
    {
        panelRanking.SetActive(false);
    }
}