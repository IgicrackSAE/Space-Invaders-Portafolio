using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    [Header("Configuraci�n de Enemigos")]
    [SerializeField] private EnemyGridManager gridManager;
    [SerializeField] private EnemyMovement movementScript;

    [Header("Configuraci�n de Oleadas")]
    [SerializeField] private float timeBetweenWaves = 2.0f;
    [SerializeField] private float speedMultiplierPerWave = 1.15f;

    private int currentWave = 1;
    private bool isTransitioningWave = false;
    private bool isGameOver = false;
    private Vector3 initialGridPosition;

    private void Awake()
    {
        if (Instance == null) Instance = this;
        else { Destroy(gameObject); return; }
    }

    private void Start()
    {
        Time.timeScale = 1f;
        initialGridPosition = movementScript != null ? movementScript.transform.position : Vector3.zero;
    }

    private void Update()
    {
        if (isTransitioningWave || isGameOver) return;
        if (AreAllEnemiesDefeated()) StartCoroutine(NextWaveRoutine());
    }

    private IEnumerator NextWaveRoutine()
    {
        isTransitioningWave = true;
        currentWave++;
        if (UIManager.Instance != null) UIManager.Instance.SumarPuntos(10000);
        yield return new WaitForSeconds(timeBetweenWaves);

        Bunker[] todosLosBunkeres = Object.FindObjectsByType<Bunker>(FindObjectsInactive.Include);
        foreach (Bunker bunker in todosLosBunkeres) bunker.Regenerar();

        if (movementScript != null)
        {
            movementScript.SetNewWaveSpeed(speedMultiplierPerWave);
            movementScript.transform.position = initialGridPosition;
        }
        if (gridManager != null) gridManager.GenerarOleada();
        isTransitioningWave = false;
    }

    private bool AreAllEnemiesDefeated()
    {
        if (gridManager == null) return false;
        foreach (Transform child in gridManager.transform) if (child.gameObject.activeSelf) return false;
        return true;
    }

    public void PerderJuego()
    {
        if (isGameOver) return;
        isGameOver = true;

        if (UIManager.Instance != null)
        {
            int puntosFinales = UIManager.Instance.GetScore();
            RegistrarPuntajeEnRanking(puntosFinales);
            PlayerPrefs.Save();
        }

        SceneManager.LoadScene("Menu_Principal");
    }

    private void RegistrarPuntajeEnRanking(int nuevoPuntaje)
    {
        string nombre = PlayerPrefs.GetString("JugadorActual", "Anonimo");
        Debug.Log("Intentando guardar: " + nombre + " con " + nuevoPuntaje + " puntos.");

        for (int i = 1; i <= 10; i++)
        {
            int recordActual = PlayerPrefs.GetInt("Score" + i, 0);
            if (nuevoPuntaje > recordActual)
            {
                Debug.Log("�Nuevo r�cord en puesto " + i + "!");
                PlayerPrefs.SetString("Name" + i, nombre);
                PlayerPrefs.SetInt("Score" + i, nuevoPuntaje);
                PlayerPrefs.Save();
                break;
            }
        }
    }
}