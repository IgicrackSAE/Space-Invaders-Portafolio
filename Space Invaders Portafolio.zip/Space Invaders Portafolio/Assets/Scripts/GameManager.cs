using System.Collections;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    [SerializeField] private EnemyGridManager gridManager;
    [SerializeField] private EnemyMovement movementScript;
    [SerializeField] private float timeBetweenWaves = 2.0f;
    [SerializeField] private float speedMultiplierPerWave = 1.15f;

    private int currentWave = 1;
    private bool isTransitioningWave = false;
    private Vector3 initialGridPosition;

    private void Start()
    {
        if (gridManager == null)
        {
            Debug.LogError($"Falta asignar el 'EnemyGridManager' en {gameObject.name}.", gameObject);
        }

        if (movementScript == null)
        {
            Debug.LogError($"Falta asignar el 'EnemyMovement' en {gameObject.name}.", gameObject);
        }
        else
        {
            initialGridPosition = movementScript.transform.position;
        }
    }

    private void Update()
    {
        if (isTransitioningWave) return;

        if (AreAllEnemiesDefeated())
        {
            StartCoroutine(NextWaveRoutine());
        }
    }

    private IEnumerator NextWaveRoutine()
    {
        isTransitioningWave = true;
        currentWave++;

        yield return new WaitForSeconds(timeBetweenWaves);

        if (movementScript != null)
        {
            movementScript.SetNewWaveSpeed(speedMultiplierPerWave);
            movementScript.transform.position = initialGridPosition;
        }

        if (gridManager != null)
        {
            gridManager.GenerarOleada();
        }

        isTransitioningWave = false;
    }

    private bool AreAllEnemiesDefeated()
    {
        if (gridManager == null) return false;

        foreach (Transform child in gridManager.transform)
        {
            if (child.gameObject.activeSelf)
            {
                return false;
            }
        }
        return true;
    }
}