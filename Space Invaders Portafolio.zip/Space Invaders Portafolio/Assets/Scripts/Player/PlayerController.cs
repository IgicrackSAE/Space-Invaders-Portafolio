using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class PlayerController : MonoBehaviour
{
    [SerializeField] private float speed = 6.0f;
    [SerializeField] private float xScreenLimit = 7.5f;

    private float horizontalInput;
    private Rigidbody2D rb;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        rb.bodyType = RigidbodyType2D.Kinematic;
        rb.gravityScale = 0f;
    }

    private void Update()
    {
        horizontalInput = 0f;

        if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow))
        {
            horizontalInput = -1f;
        }
        else if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow))
        {
            horizontalInput = 1f;
        }
    }

    private void FixedUpdate()
    {
        if (Mathf.Abs(horizontalInput) > 0.01f)
        {
            float moveX = horizontalInput * speed * Time.fixedDeltaTime;
            Vector2 nextPosition = rb.position + new Vector2(moveX, 0f);

            nextPosition.x = Mathf.Clamp(nextPosition.x, -xScreenLimit, xScreenLimit);

            rb.MovePosition(nextPosition);
        }
    }
}