using UnityEngine;

public class EnemyBullet : MonoBehaviour
{
    [SerializeField] private float speed = 5f;
    [SerializeField] private float yLimit = -6f;

    private void Update()
    {
        transform.position += Vector3.down * speed * Time.deltaTime;

        if (transform.position.y < yLimit)
        {
            gameObject.SetActive(false);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        // Detecta si el objeto con el que choc� tiene la etiqueta "Player"
        if (other.CompareTag("Player"))
        {
            gameObject.SetActive(false); // Apaga la bala
        }
    }
}