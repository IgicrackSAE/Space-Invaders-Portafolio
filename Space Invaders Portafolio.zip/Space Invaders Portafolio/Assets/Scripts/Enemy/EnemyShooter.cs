using UnityEngine;

public class EnemyShooter : MonoBehaviour
{
    [SerializeField] private float minFireInterval = 2.0f;
    [SerializeField] private float maxFireInterval = 10.0f;
    [SerializeField] private float raycastDistance = 5.0f;
    [SerializeField] private LayerMask enemyLayer;

    private EnemyBulletPool bulletPool;
    private float nextFireTime;

    private void Start()
    {
        CalculateNextFireTime();
    }

    public void SetBulletPool(EnemyBulletPool pool)
    {
        bulletPool = pool;
    }

    private void Update()
    {
        if (Time.time >= nextFireTime)
        {
            if (IsFrontRow())
            {
                Shoot();
            }
            CalculateNextFireTime();
        }
    }

    private bool IsFrontRow()
    {
        Vector2 origin = transform.position;
        RaycastHit2D hit = Physics2D.Raycast(origin + Vector2.down * 0.6f, Vector2.down, raycastDistance, enemyLayer);

        if (hit.collider != null)
        {
            return false;
        }

        return true;
    }

    private void Shoot()
    {
        if (bulletPool == null) return;

        GameObject bullet = bulletPool.GetBullet();
        if (bullet != null)
        {
            bullet.transform.position = transform.position + Vector3.down * 0.5f;
            bullet.transform.rotation = Quaternion.identity;
            bullet.SetActive(true);
        }
    }

    private void CalculateNextFireTime()
    {
        nextFireTime = Time.time + Random.Range(minFireInterval, maxFireInterval);
    }
}